# kurs_gita
Kurs gita - Zaprogramuj życie

Okazało się, że jest to całkiem fajny merytoryczny kurs.
Na pewno bardzo mi się przyda.

Dodatkowa zmiana dla testu.

ZMIANA DOKONYWANIA W FIRST_BRANCH

And third branch

1 2 3
// tutaj będzie metoda testowa
New pull request test

